#!/bin/bash

SERVER_IP="127.0.0.1"  # Replace with your server's IP address
PORT=8080              # Replace with your server's UDP port

# Loop over different message sizes (from 1KB to 32KB)
for size in $(seq 1 32)
do
    # Convert to bytes (e.g., 1KB = 1024, 2KB = 2048, etc.)
    MESSAGE_SIZE=$((size * 1024))

    echo "Running client with message size: ${size}KB"

    # Run the client with the message size
    ./client $SERVER_IP $PORT $MESSAGE_SIZE

    echo "-------------------------------------------------"
done

