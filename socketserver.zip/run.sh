#!/bin/bash

# Server IP and port number
SERVER_IP=$1
PORT=$2
PAYLOAD_SIZE=$3
NUM_CLIENTS=$4

# Function to run a client instance
run_client() {
    ./client $SERVER_IP $PORT $PAYLOAD_SIZE &
}

# Loop to run NUM_CLIENTS client instances in parallel
for ((i = 1; i <= NUM_CLIENTS; i++)); do
    run_client
    echo "Started client $i"
done

# Wait for all background clients to finish
wait
echo "All clients have finished."

