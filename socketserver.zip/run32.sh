#!/bin/bash

SERVER_IP="127.0.0.1"
TCP_PORT=8080
OUT_FILE="throughput_results.csv"
GNUPLOT_FILE="plot_throughput.gp"

# Number of clients to launch (32 clients)
NUM_CLIENTS=32

# Create or overwrite the output CSV file
echo "MessageSize(Bytes),Throughput(KBps)" > $OUT_FILE

# Launch clients in parallel for each payload size from 1KB to 32KB
for i in $(seq 1 $NUM_CLIENTS)
do
    SIZE=$((i * 1024))  # Multiply by 1024 to get sizes from 1KB to 32KB
    {
        echo "Testing message size: $SIZE bytes"
        
        # Run the client and capture output
        OUTPUT=$(./client "$SERVER_IP" "$TCP_PORT" "$SIZE")
        
        # Extract throughput using grep + awk
        THROUGHPUT=$(echo "$OUTPUT" | grep "Throughput:" | awk '{print $2}')
        
        if [ -z "$THROUGHPUT" ]; then
            echo "No throughput found for size $SIZE. Skipping."
            continue
        fi

        # Append result to the output CSV file
        echo "$SIZE,$THROUGHPUT" >> $OUT_FILE
    } &  # Run each client in the background
done

# Wait for all background tasks to finish
wait

# Generate gnuplot script
cat <<EOF > $GNUPLOT_FILE
set title "UDP Throughput vs Message Size"
set xlabel "Message Size (Bytes)"
set ylabel "Throughput (KB/s)"
set grid
set datafile separator ","
set terminal pngcairo size 800,600 enhanced font 'Verdana,10'
set output "throughput_plot.png"
plot "$OUT_FILE" using 1:2 with linespoints title "Client Throughput"
EOF

# Plot the throughput using gnuplot
gnuplot $GNUPLOT_FILE

echo "Plot saved as throughput_plot.png"

