#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/time.h>

#define MAX_MSG_LEN 1024

// Error handling function
void error(const char *msg)
{
    perror(msg);
    exit(1);
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Port number not provided. Connection terminated.\n");
        exit(1);
    }

    int server_fd, newsocketfd, n;
    struct sockaddr_in serv_addr, cli_addr;
    int port_no = atoi(argv[1]);
    socklen_t clilen;

    // Create TCP socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        error("Error opening socket.");
    }

    // Zero out the server address struct
    memset(&serv_addr, 0, sizeof(serv_addr));

    // Set up the server address
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port_no);

    // Bind the server address to the socket
    if (bind(server_fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        error("Error binding.");
    }

    // Listen for incoming connections
    listen(server_fd, 3);

    printf("Waiting for connection request on port %d...\n", port_no);
    clilen = sizeof(cli_addr);
    newsocketfd = accept(server_fd, (struct sockaddr *)&cli_addr, &clilen);
    if (newsocketfd < 0) {
        error("Error accepting.");
    }

    char client_ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &cli_addr.sin_addr, client_ip, INET_ADDRSTRLEN);
    printf("Connection established with client %s:%d\n", client_ip, ntohs(cli_addr.sin_port));

    // Buffer to store the incoming data
    char buffer[MAX_MSG_LEN];
    int total_received = 0;

    // Start the timer to calculate throughput
    struct timeval start, end;
    gettimeofday(&start, NULL);

    // Receive data in a loop (the size is defined by the client)
    while (1) {
        n = recv(newsocketfd, buffer, MAX_MSG_LEN, 0);
        if (n < 0) {
            error("Error reading message from client.");
        } else if (n == 0) {
            break;  // Connection closed by client
        }

        total_received += n;
    }

    // Stop the timer
    gettimeofday(&end, NULL);

    // Calculate the time taken for the transfer in seconds and microseconds
    double time_taken = (end.tv_sec - start.tv_sec) * 1000.0; // seconds to milliseconds
    time_taken += (end.tv_usec - start.tv_usec) / 1000.0; // microseconds to milliseconds

    // Calculate the throughput in KB/s
    double throughput = (total_received / 1024.0) / (time_taken / 1000.0); // KB per second

    // Display the result
    printf("Received %d bytes in %.2f ms. Throughput: %.2f KB/s\n", total_received, time_taken, throughput);

    // Close the connection
    close(newsocketfd);
    close(server_fd);
    return 0;
}

