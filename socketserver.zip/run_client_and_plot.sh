#!/bin/bash

SERVER_IP="127.0.0.1"
TCP_PORT=8080
OUT_FILE="throughput_results.csv"
GNUPLOT_FILE="plot_throughput.gp"

# Message sizes to test (in bytes)
SIZES=(1024 2048 4096 8192 10240 16384 20480 25600 29696 32768)

echo "MessageSize(Bytes),Throughput(KBps)" > $OUT_FILE

for size in "${SIZES[@]}"
do
    echo "Testing message size: $size bytes"
    # Run the client and capture output
    OUTPUT=$(./client "$SERVER_IP" "$TCP_PORT" "$size")
    
    # Extract throughput using grep + awk
    THROUGHPUT=$(echo "$OUTPUT" | grep "Throughput:" | awk '{print $2}')
    
    if [ -z "$THROUGHPUT" ]; then
        echo "No throughput found for size $size. Skipping."
        continue
    fi

    echo "$size,$THROUGHPUT" >> $OUT_FILE
done

# Generate gnuplot script
cat <<EOF > $GNUPLOT_FILE
set title "UDP Throughput vs Message Size"
set xlabel "Message Size (Bytes)"
set ylabel "Throughput (KB/s)"
set grid
set datafile separator ","
set terminal pngcairo size 800,600 enhanced font 'Verdana,10'
set output "throughput_plot.png"
plot "$OUT_FILE" using 1:2 with linespoints title "Client Throughput"
EOF

# Plot
gnuplot $GNUPLOT_FILE

echo "Plot saved as throughput_plot.png"

