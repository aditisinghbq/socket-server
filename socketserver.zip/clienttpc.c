#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/time.h>

#define MAX_MSG_LEN 1024

void error(const char *msg)
{
    perror(msg);
    exit(1);
}

void send_data(int sockfd, char *data, int size) {
    int total_sent = 0;
    int bytes_sent;
    while (total_sent < size) {
        bytes_sent = send(sockfd, data + total_sent, size - total_sent, 0);
        if (bytes_sent < 0) {
            error("Error sending data");
        }
        total_sent += bytes_sent;
    }
}

int main(int argc, char *argv[])
{
    if (argc != 4) {
        fprintf(stderr, "Usage: %s <server_ip> <port> <data_size_in_kb>\n", argv[0]);
        exit(1);
    }

    char *server_ip = argv[1];
    int port = atoi(argv[2]);
    int data_size_kb = atoi(argv[3]);
    int data_size = data_size_kb * 1024; // Convert KB to Bytes
    char *data = malloc(data_size);

    // Fill the data buffer with some content
    memset(data, 'A', data_size);

    int sockfd;
    struct sockaddr_in server_addr;

    // Create socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        error("Error opening socket");
    }

    memset(&server_addr, 0, sizeof(server_addr));

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = inet_addr(server_ip);

    // Connect to the server
    if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        error("Error connecting to server");
    }

    // Start timing
    struct timeval start, end;
    gettimeofday(&start, NULL);

    // Send data
    send_data(sockfd, data, data_size);

    // End timing
    gettimeofday(&end, NULL);

    // Calculate time taken
    double time_taken = (end.tv_sec - start.tv_sec) * 1000.0; // seconds to milliseconds
    time_taken += (end.tv_usec - start.tv_usec) / 1000.0; // microseconds to milliseconds

    // Calculate throughput (KB/s)
    double throughput = (data_size_kb) / (time_taken / 1000.0); // KB per second

    printf("Sent %d KB in %.2f ms. Throughput: %.2f KB/s\n", data_size_kb, time_taken, throughput);

    close(sockfd);
    free(data);
    return 0;
}

